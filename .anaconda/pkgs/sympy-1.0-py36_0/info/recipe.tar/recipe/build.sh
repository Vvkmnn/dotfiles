#!/bin/bash

$PYTHON setup.py install

rm -rf $PREFIX/share

import jsonschema

assert jsonschema.__version__ == '2.6.0'

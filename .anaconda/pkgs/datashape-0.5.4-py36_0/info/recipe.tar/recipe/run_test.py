import datashape

print('datashape.__version__: %s' % datashape.__version__)

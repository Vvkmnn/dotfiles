#!/bin/bash

rm -rf $PREFIX/Anaconda-Navigator.app
rm -f /Applications/Anaconda-Navigator.app
rm -f $HOME/Applications/Anaconda-Navigator.app

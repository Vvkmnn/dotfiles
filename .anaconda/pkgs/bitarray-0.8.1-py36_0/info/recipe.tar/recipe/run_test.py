import bitarray

assert bitarray.test().wasSuccessful()

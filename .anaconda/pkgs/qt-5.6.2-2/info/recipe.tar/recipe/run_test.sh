#!/bin/bash

cd test
qmake hello.pro
make
./hello

from __future__ import print_function, absolute_import

__version__ = "__VERSION__"
__name__ = "ruamel_yaml"
__author__ = "Anthon van der Neut"
__author_email__ ="a.van.der.neut@ruamel.eu"
__with_libyaml__ = True

from .cyaml import *
from .main import *

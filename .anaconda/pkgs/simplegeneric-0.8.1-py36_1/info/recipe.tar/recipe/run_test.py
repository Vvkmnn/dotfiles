from simplegeneric import generic

#!/bin/bash

$PYTHON setup.py version_module
$PYTHON setup.py install

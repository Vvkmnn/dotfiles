# This empty file makes the backports namespace package work.
# It is the only file included in the 'backports' conda package.
# Conda packages which use the backports namespace do not include
# this file, but depend on the 'backports' conda package instead.

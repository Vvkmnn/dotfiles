import psutil

psutil.test()
